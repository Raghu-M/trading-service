package com.hcl.trade.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.trade.model.Stock;
import com.hcl.trade.service.StockService;



@RestController
@RequestMapping("/stock")
public class StockController {
	
	@Autowired
	StockService stockService;
	
	@GetMapping("/stockList/")
	public List<Stock> userList(){ 
		return (List<Stock>) stockService.StockList();
	}

}
