package com.hcl.trade.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.trade.model.Stock;
import com.hcl.trade.repository.StockRepository;

@Service
public class StockServiceImpl implements StockService {
	
	@Autowired
	StockRepository stockRepository;

	@Override
	public List<Stock> StockList() {
		return (List<Stock>) stockRepository.findAll();
	}

	@Override
	public Stock getStock(int stockId) {
		return stockRepository.findById(stockId).get();
	}

	@Override
	public boolean saveStock(Stock stock) {
		stockRepository.save(stock);
		return true;

	}

}
