package com.hcl.trade.service;

import java.util.List;

import com.hcl.trade.domain.Buy;
import com.hcl.trade.model.UserStock;

public interface UserStockService {
	
	List<UserStock> userStockList(int userId);
	String userBuy(Buy buy);

}
