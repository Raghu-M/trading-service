package com.hcl.trade.service;

import java.util.List;

import com.hcl.trade.model.Stock;

public interface StockService {
	
	public List<Stock> StockList();
	public Stock getStock(int stockId);
	public boolean saveStock(Stock stock);
	

}
