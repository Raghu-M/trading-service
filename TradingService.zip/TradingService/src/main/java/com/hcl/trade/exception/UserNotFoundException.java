package com.hcl.trade.exception;

public class UserNotFoundException extends RuntimeException{

}
