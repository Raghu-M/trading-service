package com.hcl.trade.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="user_stock")
public class UserStock {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int orderId;
	private int userId;
	private String stockName;
	private int quantity;
	private double unitPrice;
	private double totalPrice;
	private int brokerage;
	private double brokerageAmount;
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getStockName() {
		return stockName;
	}
	public void setStockName(String stockName) {
		this.stockName = stockName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public int getBrokerage() {
		return brokerage;
	}
	public void setBrokerage(int brokerage) {
		this.brokerage = brokerage;
	}
	public double getBrokerageAmount() {
		return brokerageAmount;
	}
	public void setBrokerageAmount(double brokerageAmount) {
		this.brokerageAmount = brokerageAmount;
	}
	@Override
	public String toString() {
		return "UserStock [orderId=" + orderId + ", userId=" + userId + ", stockName=" + stockName + ", quantity="
				+ quantity + ", unitPrice=" + unitPrice + ", totalPrice=" + totalPrice + ", brokerage=" + brokerage
				+ ", brokerageAmount=" + brokerageAmount + "]";
	}
	
	
	
	

}
