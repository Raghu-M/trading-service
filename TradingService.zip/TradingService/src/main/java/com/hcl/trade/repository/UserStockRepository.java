package com.hcl.trade.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.hcl.trade.model.UserStock;

public interface UserStockRepository extends CrudRepository<UserStock, Integer> {
	
	List<UserStock> findAllByUserId(int userId);

}
