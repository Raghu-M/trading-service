package com.hcl.trade.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.hcl.trade.exception.UserNotFoundException;
import com.hcl.trade.model.User;
import com.hcl.trade.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserRepository userRepository;

	@Override
	@ExceptionHandler
	public User getUser(int userId) {
		return userRepository.findById(userId).get();
	}

}
