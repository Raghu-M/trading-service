package com.hcl.trade.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.trade.domain.Buy;
import com.hcl.trade.model.UserStock;
import com.hcl.trade.service.UserStockService;

@RestController
@RequestMapping("/userStock")
public class UserStockController {
	
	@Autowired
	UserStockService userStockService;
	
	@GetMapping("/stockList/{userId}")
	public List<UserStock> userList(@PathVariable int userId){ 
		return (List<UserStock>) userStockService.userStockList(userId);
	}
	
	@PostMapping("/buy")
	public String buy(@RequestBody Buy buy){ 
		return userStockService.userBuy(buy);
	}

}
