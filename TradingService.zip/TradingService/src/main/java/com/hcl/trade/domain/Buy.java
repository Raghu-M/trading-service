package com.hcl.trade.domain;

public class Buy {
	
	private int userId;
	private int stockId;
	private int quantity;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getStockId() {
		return stockId;
	}
	public void setStockId(int stockId) {
		this.stockId = stockId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "buy [userId=" + userId + ", stockId=" + stockId + ", quantity=" + quantity + "]";
	}
	
	

}
