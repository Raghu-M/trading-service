package com.hcl.trade.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.trade.domain.Buy;
import com.hcl.trade.model.Stock;
import com.hcl.trade.model.UserStock;
import com.hcl.trade.repository.UserStockRepository;

@Service
public class UserStockServiceImpl implements UserStockService {

	@Autowired
	UserStockRepository userStockRepository;
	@Autowired
	UserService userService;
	@Autowired
	StockService stockService;

	@Override
	public List<UserStock> userStockList(int userId) {
		return userStockRepository.findAllByUserId(userId);
	}

	@Override
	public String userBuy(Buy buy) {
		Stock stock = stockService.getStock(buy.getStockId());

		if (userService.getUser(buy.getUserId()) == null) {
			return "User Not Found";
		} else if (stock == null) {
			return "Stock Not Found";
		} else {
			if (stock.getQuantity() >= buy.getQuantity()) {
				UserStock userStock = new UserStock();
				userStock.setUserId(buy.getUserId());
				userStock.setQuantity(buy.getQuantity());
				userStock.setBrokerage(stock.getBrokerage());
				userStock.setUnitPrice(stock.getUnitPrice());
				userStock.setStockName(stock.getName());
				userStock.setBrokerageAmount((stock.getUnitPrice() * buy.getQuantity() * stock.getBrokerage()) / 100);
				userStock.setTotalPrice(stock.getUnitPrice() * buy.getQuantity() + userStock.getBrokerageAmount());
				userStockRepository.save(userStock);
				stock.setQuantity(stock.getQuantity() - buy.getQuantity());
				stockService.saveStock(stock);
				return "order successfull";
			} else {
				return "Quantity not Available";
			}

		}
	}

}
