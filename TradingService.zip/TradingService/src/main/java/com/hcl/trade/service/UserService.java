package com.hcl.trade.service;

import com.hcl.trade.model.User;

public interface UserService {
	
	public User getUser(int userId);

}
