package com.hcl.trade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TradingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
